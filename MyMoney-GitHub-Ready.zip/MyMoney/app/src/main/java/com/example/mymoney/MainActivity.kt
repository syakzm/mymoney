package com.example.mymoney

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF101018)
private val Panel = Color(0xFF1B1B28)
private val Purple = Color(0xFF9B7BFF)
private val Green = Color(0xFF63D6A2)
private val Red = Color(0xFFFF7888)
private val Muted = Color(0xFF9998AA)
private val White = Color(0xFFF5F3FF)

data class Tx(val id: Long, val title: String, val amount: Long, val category: String, val income: Boolean, val date: String)
data class Goal(val id: Long, val name: String, val target: Long, val saved: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyMoneyApp(this) }
    }
}

private fun rupiah(value: Long): String =
    NumberFormat.getCurrencyInstance(Locale("id", "ID")).format(value).replace(",00", "")

private fun loadTransactions(context: Context): List<Tx> {
    val raw = context.getSharedPreferences("mymoney", Context.MODE_PRIVATE).getString("transactions", "[]") ?: "[]"
    val arr = JSONArray(raw)
    return (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        Tx(o.getLong("id"), o.getString("title"), o.getLong("amount"), o.getString("category"), o.getBoolean("income"), o.getString("date"))
    }.sortedByDescending { it.id }
}

private fun saveTransactions(context: Context, items: List<Tx>) {
    val arr = JSONArray()
    items.forEach {
        arr.put(JSONObject().put("id", it.id).put("title", it.title).put("amount", it.amount)
            .put("category", it.category).put("income", it.income).put("date", it.date))
    }
    context.getSharedPreferences("mymoney", Context.MODE_PRIVATE).edit().putString("transactions", arr.toString()).apply()
}

private fun loadGoals(context: Context): List<Goal> {
    val raw = context.getSharedPreferences("mymoney", Context.MODE_PRIVATE).getString("goals", "[]") ?: "[]"
    val arr = JSONArray(raw)
    return (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        Goal(o.getLong("id"), o.getString("name"), o.getLong("target"), o.getLong("saved"))
    }
}

private fun saveGoals(context: Context, items: List<Goal>) {
    val arr = JSONArray()
    items.forEach {
        arr.put(JSONObject().put("id", it.id).put("name", it.name).put("target", it.target).put("saved", it.saved))
    }
    context.getSharedPreferences("mymoney", Context.MODE_PRIVATE).edit().putString("goals", arr.toString()).apply()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyMoneyApp(context: Context) {
    var transactions by remember { mutableStateOf(loadTransactions(context)) }
    var goals by remember { mutableStateOf(loadGoals(context)) }
    var tab by remember { mutableIntStateOf(0) }
    var showTx by remember { mutableStateOf(false) }
    var showGoal by remember { mutableStateOf(false) }
    var showDeposit by remember { mutableStateOf<Goal?>(null) }

    val income = transactions.filter { it.income }.sumOf { it.amount }
    val expense = transactions.filter { !it.income }.sumOf { it.amount }
    val savedTotal = goals.sumOf { it.saved }
    val balance = income - expense - savedTotal

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, background = Bg, surface = Panel, onBackground = White, onSurface = White
    )) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).background(Purple, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.AccountBalanceWallet, null, tint = Color.White)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("MyMoney", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text("Atur uang, capai tujuan.", color = Muted, fontSize = 11.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.DarkMode, null, tint = Muted)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = White) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Beranda") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Savings, null) }, label = { Text("Tabungan") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.ReceiptLong, null) }, label = { Text("Transaksi") })
                }
            },
            floatingActionButton = {
                if (tab != 1) FloatingActionButton(onClick = { showTx = true }, containerColor = Purple, contentColor = Color.White) {
                    Icon(Icons.Default.Add, contentDescription = "Tambah transaksi")
                } else FloatingActionButton(onClick = { showGoal = true }, containerColor = Purple, contentColor = Color.White) {
                    Icon(Icons.Default.Add, contentDescription = "Tambah target tabungan")
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(padding, balance, income, expense, savedTotal, transactions.take(5))
                1 -> SavingsScreen(padding, goals, onAdd = { showGoal = true }, onDeposit = { showDeposit = it })
                else -> TransactionsScreen(padding, transactions)
            }
        }

        if (showTx) AddTransactionDialog(
            onDismiss = { showTx = false },
            onSave = { title, amount, category, isIncome ->
                val tx = Tx(System.currentTimeMillis(), title, amount, category, isIncome,
                    SimpleDateFormat("dd MMM yyyy", Locale("id", "ID")).format(Date()))
                transactions = (listOf(tx) + transactions)
                saveTransactions(context, transactions)
                showTx = false
            }
        )
        if (showGoal) AddGoalDialog(onDismiss = { showGoal = false }, onSave = { name, target ->
            goals = goals + Goal(System.currentTimeMillis(), name, target, 0L)
            saveGoals(context, goals)
            showGoal = false
        })
        showDeposit?.let { goal ->
            DepositDialog(goal, onDismiss = { showDeposit = null }, onSave = { amount ->
                goals = goals.map { if (it.id == goal.id) it.copy(saved = it.saved + amount) else it }
                saveGoals(context, goals)
                showDeposit = null
            })
        }
    }
}

@Composable
private fun HomeScreen(padding: PaddingValues, balance: Long, income: Long, expense: Long, saved: Long, recent: List<Tx>) {
    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp), contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(brush = androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF7554D8), Color(0xFF3E347A))), RoundedCornerShape(24.dp)).padding(22.dp)) {
                Text("TOTAL UANG TERSEDIA", color = Color(0xFFDCD3FF), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(rupiah(balance), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Savings, null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Tersimpan di target: ${rupiah(saved)}", color = Color.White.copy(alpha = .9f), fontSize = 12.sp)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SummaryCard("Pemasukan", income, Green, Icons.Default.TrendingUp, Modifier.weight(1f))
                SummaryCard("Pengeluaran", expense, Red, Icons.Default.TrendingDown, Modifier.weight(1f))
            }
        }
        item { Text("Transaksi terbaru", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        if (recent.isEmpty()) item { EmptyState("Belum ada transaksi", "Tekan tombol + untuk mencatat uang masuk atau keluar.") }
        items(recent, key = { it.id }) { TransactionRow(it) }
    }
}

@Composable
private fun SummaryCard(label: String, amount: Long, color: Color, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(18.dp)).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = color, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(label, color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(rupiah(amount), color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SavingsScreen(padding: PaddingValues, goals: List<Goal>, onAdd: () -> Unit, onDeposit: (Goal) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp), contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Target tabungan", color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("Sisihkan uang sedikit demi sedikit.", color = Muted, fontSize = 13.sp)
        }
        if (goals.isEmpty()) item { EmptyState("Belum ada target", "Buat target pertamamu, misalnya dana laptop atau tabungan pribadi.") }
        items(goals, key = { it.id }) { goal ->
            val progress = if (goal.target > 0) (goal.saved.toFloat() / goal.target).coerceIn(0f, 1f) else 0f
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(17.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Purple.copy(alpha = .18f), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Savings, null, tint = Purple)
                    }
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f)) {
                        Text(goal.name, color = White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Text("${rupiah(goal.saved)} dari ${rupiah(goal.target)}", color = Muted, fontSize = 12.sp)
                    }
                    Text("${(progress * 100).toInt()}%", color = Purple, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(14.dp))
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Purple, trackColor = Color(0xFF343344))
                Spacer(Modifier.height(13.dp))
                Button(onClick = { onDeposit(goal) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple), shape = RoundedCornerShape(12.dp)) {
                    Icon(Icons.Default.Add, null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Tambah tabungan")
                }
            }
        }
        item { TextButton(onClick = onAdd) { Text("+ Buat target baru", color = Purple) } }
    }
}

@Composable
private fun TransactionsScreen(padding: PaddingValues, transactions: List<Tx>) {
    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp), contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Semua transaksi", color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("${transactions.size} catatan tersimpan di perangkat ini", color = Muted, fontSize = 12.sp)
        }
        if (transactions.isEmpty()) item { EmptyState("Belum ada transaksi", "Catat pemasukan atau pengeluaran pertamamu.") }
        items(transactions, key = { it.id }) { TransactionRow(it) }
    }
}

@Composable
private fun TransactionRow(tx: Tx) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).background((if (tx.income) Green else Red).copy(alpha = .15f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(if (tx.income) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, null, tint = if (tx.income) Green else Red)
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(tx.title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text("${tx.category} • ${tx.date}", color = Muted, fontSize = 11.sp)
        }
        Text((if (tx.income) "+ " else "- ") + rupiah(tx.amount), color = if (tx.income) Green else Red, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.AccountBalanceWallet, null, tint = Purple, modifier = Modifier.size(32.dp))
        Spacer(Modifier.height(9.dp))
        Text(title, color = White, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun AddTransactionDialog(onDismiss: () -> Unit, onSave: (String, Long, String, Boolean) -> Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Makan") }
    var isIncome by remember { mutableStateOf(false) }
    val categories = if (isIncome) listOf("Gaji/uang saku", "Hadiah", "Lainnya") else listOf("Makan", "Transportasi", "Belanja", "Kuliah", "Hiburan", "Lainnya")
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text("Tambah transaksi", color = White) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !isIncome, onClick = { isIncome = false; category = "Makan" }, label = { Text("Pengeluaran") })
                FilterChip(selected = isIncome, onClick = { isIncome = true; category = "Gaji/uang saku" }, label = { Text("Pemasukan") })
            }
            OutlinedTextField(title, { title = it }, label = { Text("Nama transaksi") }, singleLine = true)
            OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Nominal (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            Text("Kategori", color = Muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                categories.take(3).forEach { c -> FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c, fontSize = 10.sp) }) }
            }
            if (categories.size > 3) Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                categories.drop(3).forEach { c -> FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c, fontSize = 10.sp) }) }
            }
        }
    }, confirmButton = {
        TextButton(onClick = { val n = amount.toLongOrNull() ?: 0L; if (title.isNotBlank() && n > 0) onSave(title.trim(), n, category, isIncome) }) { Text("Simpan", color = Purple) }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = Muted) } })
}

@Composable
private fun AddGoalDialog(onDismiss: () -> Unit, onSave: (String, Long) -> Unit) {
    var name by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text("Buat target tabungan", color = White) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Nama target") }, singleLine = true)
            OutlinedTextField(target, { target = it.filter(Char::isDigit) }, label = { Text("Target nominal (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
        }
    }, confirmButton = { TextButton(onClick = { val n = target.toLongOrNull() ?: 0L; if (name.isNotBlank() && n > 0) onSave(name.trim(), n) }) { Text("Buat", color = Purple) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = Muted) } })
}

@Composable
private fun DepositDialog(goal: Goal, onDismiss: () -> Unit, onSave: (Long) -> Unit) {
    var amount by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text("Tambah tabungan", color = White) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(goal.name, color = Muted)
                Text("Terkumpul: ${rupiah(goal.saved)}", color = White)
                OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Nominal (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { val n = amount.toLongOrNull() ?: 0L; if (n > 0) onSave(n) }) { Text("Simpan", color = Purple) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = Muted) } })
}
