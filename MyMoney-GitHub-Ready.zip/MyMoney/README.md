# MyMoney

Aplikasi pencatat keuangan pribadi Android dengan Kotlin dan Jetpack Compose.

## Fitur
- Dashboard saldo tersedia, pemasukan, pengeluaran, dan uang yang sudah dialokasikan ke tabungan.
- Tambah transaksi pemasukan/pengeluaran beserta kategori.
- Buat beberapa target tabungan dan tambahkan setoran ke tiap target.
- Riwayat transaksi.
- Data disimpan lokal di SharedPreferences perangkat, tanpa akun atau server.

## Cara membuka dan membuat APK
1. Ekstrak ZIP ini.
2. Buka Android Studio, pilih **Open**, lalu pilih folder `MyMoney`.
3. Tunggu Gradle Sync selesai. Jika diminta, pasang Android SDK Platform 35 dan JDK 17.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
- Saldo tersedia dihitung sebagai total pemasukan dikurangi total pengeluaran dan total uang yang dialokasikan ke target tabungan.
- Versi awal ini belum menyediakan ekspor data, sinkronisasi cloud, atau proteksi PIN.

## Build otomatis lewat GitHub Actions
1. Buat repository GitHub baru, misalnya `MyMoney`.
2. Upload seluruh isi folder project ini ke repository (termasuk folder `.github/workflows`).
3. Buka tab **Actions** pada repository dan aktifkan Actions jika diminta.
4. Workflow **Build MyMoney APK** akan berjalan otomatis setelah push ke branch `main`.
5. Buka hasil workflow yang selesai, cari bagian **Artifacts**, lalu unduh `MyMoney-debug-APK`.
6. Ekstrak ZIP artifact untuk mendapatkan `app-debug.apk`.

Workflow juga bisa dijalankan manual melalui **Actions > Build MyMoney APK > Run workflow**.
